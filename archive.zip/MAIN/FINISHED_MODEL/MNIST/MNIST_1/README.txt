5.1 MNIST (CLEAN_CODE)
1. Total Episode: 3500 (2500/500/500)
	at first 2500 episode at epsilon = 1.0
    Discount rate(Gamma): 1.0
    Q-Learning rate(Alpha): 0.01
    Number of model randomly selected to update the Q-table from experience replay: 10

    Result:
	Loss: 0.08265
	Accuracy: 0.9732
	Model: c_2,c_6,c_3,c_1
